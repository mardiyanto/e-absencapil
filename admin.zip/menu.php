 <!-- Topbar -->
 <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
<!-- Nav Item - Utilities Collapse Menu -->

                <a class="nav-link collapsed" href="index.php">
                    <i class="fas fa-home fa-fw"></i>
                    <span>Home</span>
                </a>
                <a class="nav-link collapsed" href="absen.php?aksi=datang" >
                    <i class="fas fa-camera-retro fa-lg"></i>
                    <span>Datang</span>
                </a>
                <a class="nav-link collapsed" href="absen.php?aksi=pulang">
                    <i class="fas fa-battery-half"></i>
                    <span>Pulang</span>
                </a>
              
                    <!-- Sidebar Toggle (Topbar) -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>

                </nav>